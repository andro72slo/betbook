<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "st_naloga";

$id = $_POST['id'];

$conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
        
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
            $stmt = $conn->prepare("UPDATE objava SET status = :s WHERE id = :id");
            $stmt->bindParam(':id', $_POST["id"]);
            $stmt->bindParam(':s', $_POST["s"]);
            $stmt->execute();


?>