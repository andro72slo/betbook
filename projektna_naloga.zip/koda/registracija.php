
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css?v=<?php echo time(); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta charset="UTF-8" />
<script src="script.js"></script>
<style>
    ::placeholder {
        color: red;
        opacity: 1;
    }
</style>



</head>
<body>

<div class="topnav" id="myTopnav">

  <a class="active">Betbook</a>
  <a href="nasveti.php">Nasveti</a>
  <?php
  session_start();
  if(isset($_SESSION["id"])){
      echo '<a href="dodaj.php">Objavi</a>';
      echo '<a href="mojestave.php">Moje objave</a>';
      echo '<a href="odjava.php" style="float:right">Odjava</a>';
  }
  else{
      echo '<a href="registracija.php" class="desno" style="float:right" > Registracija</a>';
      echo '<a href="prijava.php" style="float:right" >Prijava</a>';
  }
   
  ?>
  <a href="javascript:void(0);" class="icon" onclick="menu()">
    <i class="fa fa-bars"></i>
  </a>

</div>



<?php

$errors["ime"] = "";
$errors["priimek"] = "";
$errors["email"] = "";
$errors["user"] = "";
$errors["geslo"] = "";

$servername = "localhost";
$username = "root";
$password = "";

if(!empty($_POST)){

    $err = 0;

    if(strlen($_POST["ime"]) > 50){
        $errors["ime"] = "Vaše ime je predolgo";
        $err = 1;
    }

    if(strlen($_POST["priimek"]) > 50){
        $errors["priimek"] = "Vaš priimek je predolg";
        $err = 1;
    }

    if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        $errors["email"] = "Vaš elektronski naslov je napačen"; 
        $err = 1;
    }

    if(strlen($_POST["user"]) > 25){
        $errors["user"] = "Vaše uporabniško ime je predolgo";
        $err = 1;
    }

    if(strlen($_POST["geslo"]) < 5){
        $errors["geslo"] = "Vaše geslo naj vsebuje vsaj 5 znakov";
        $err = 1;
    }

    try {
        $conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
    
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $conn->prepare("SELECT * FROM uporabnik WHERE user = :user LIMIT 1");
        $stmt->bindParam(':user', $_POST["user"]);
        $stmt->execute();
        
        $result = $stmt->fetch();

        if(isset($result["ime"])){
            $errors["user"] = "Vaše uporabniško ime je že zasedeno";
            $err = 1;
        }

        }
    catch(PDOException $e)
        {
        echo "Connection failed: " . $e->getMessage();
        }

    



    if($err == 0){

        try {
            $conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
        
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
            $stmt = $conn->prepare("INSERT INTO uporabnik (ime, priimek, email, user, geslo) 
                                    VALUES (:ime, :priimek, :email, :user, :geslo)");
            $stmt->bindParam(':ime', $_POST["ime"]);
            $stmt->bindParam(':priimek', $_POST["priimek"]);
            $stmt->bindParam(':email', $_POST["email"]);
            $stmt->bindParam(':user', $_POST["user"]);
            $stmt->bindParam(':geslo', $_POST["geslo"]);
            $stmt->execute();


            $stmt = $conn->prepare("SELECT * FROM uporabnik WHERE user = :user LIMIT 1");
            $stmt->bindParam(':user', $_POST["user"]);

            $stmt->execute();
    
        
            $result = $stmt->fetch();

            session_start();
            $_SESSION["id"] = $result["id"];
            $_SESSION["ime"] = $_POST["ime"];
            $_SESSION["priimek"] = $_POST["priimek"];
            $_SESSION["email"] = $_POST["email"];
            $_SESSION["user"] = $_POST["user"];

            echo $_SESSION["email"];
            header('Location: nasveti.php'); 
            
    
    
            }
        catch(PDOException $e)
            {
            echo "Connection failed: " . $e->getMessage();
            }
    }

    

}

?>

<div class="registracija">

<div class="reg">

<form method="post">

    <div class="r">
    <p>IME</p>
    <input type="text" name="ime" placeholder="<?php echo $errors["ime"];?>" required>

    <p>PRIIMEK</p>
    <input type="text" name="priimek" placeholder="<?php echo $errors["priimek"];?>"  required>

    <p>ELEKTRONSKI NASLOV</p>
    <input type="text" name="email"  placeholder="<?php echo $errors["email"];?>" required>

    </div>

    <div class="l">
    <p>UPORABNIŠKO IME</p>
    <input type="text" name="user" placeholder="<?php echo $errors["user"];?>" required>

    <p>GESLO</p>
    <input type="password" name="geslo" placeholder="<?php echo $errors["geslo"];?>" required>
    <p></p>
    <br>
    <br>
    <input type="submit" value="REGISTRIRAJ ME">

    </div>
</form>


</div>
</div>





</body>
</html>




