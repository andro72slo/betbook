<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css?v=<?php echo time(); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta charset="UTF-8" />
<script src="script.js"></script>

</head>
<body>

<div class="topnav" id="myTopnav">

  <a class="active">Betbook</a>
  <a href="nasveti.php">Nasveti</a>
  <?php
  session_start();
  if(isset($_SESSION["id"])){
      echo '<a href="dodaj.php">Objavi</a>';
      echo '<a href="mojestave.php">Moje objave</a>';
      echo '<a href="odjava.php" style="float:right">Odjava</a>';
  }
  else{
      echo '<a href="registracija.php" class="desno" style="float:right" > Registracija</a>';
      echo '<a href="prijava.php" style="float:right" >Prijava</a>';


  }
   
  ?>
  <a href="javascript:void(0);" class="icon" onclick="menu()">
    <i class="fa fa-bars"></i>
  </a>

</div>



<?php

$errors["ime"] = "";
$errors["priimek"] = "";
$errors["email"] = "";
$errors["user"] = "";
$errors["geslo"] = "";

$servername = "localhost";
$username = "root";
$password = "";

if(!empty($_POST)){

    $err = 0;

    if(strlen($_POST["doma"]) > 50){
        $errors["ime"] = "ime je predolgo";
        $err = 1;
    }

    if(strlen($_POST["gost"]) > 50){
        $errors["priimek"] = "ime je predolgo";
        $err = 1;
    }

    if (!filter_var($_POST["kvota"], FILTER_VALIDATE_FLOAT)) {
        $errors["email"] = "Napačen format kvote"; 
        $err = 1;
    }


    if($err == 0){

        try {
            $conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
        
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
            $stmt = $conn->prepare("INSERT INTO objava (userid, sportid, doma, gost, izbira, kvota, besedilo) 
                                    VALUES (:userid, :sportid, :doma, :gost, :izbira, :kvota, :besedilo)");
            $stmt->bindParam(':userid', $_SESSION["id"]);
            $stmt->bindParam(':sportid', $_POST["sport"]);
            $stmt->bindParam(':doma', $_POST["doma"]);
            $stmt->bindParam(':gost', $_POST["gost"]);
            $stmt->bindParam(':izbira', $_POST["izbira"]);
            $stmt->bindParam(':kvota', $_POST["kvota"]);
            $stmt->bindParam(':besedilo', $_POST["besedilo"]);
            $stmt->execute();


            header('Location: nasveti.php'); 
            
    
    
            }
        catch(PDOException $e)
            {
            echo "Connection failed: " . $e->getMessage();
            }
    }

    

}

?>






<div class="dodaj">

<div class="form">

<h1 style="text-align:center" >OBJAVI STAVO</h1>

<form method="post">

    <div class="r">
    <span>ŠPORT:</span>
    <select name="sport">
        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";

            $conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
    
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
            $stmt = $conn->query("SELECT * FROM sport");
            while ($row = $stmt->fetch()) {
                echo "<option value=".$row["id"].">".$row['naziv']."</option>";
            }
        ?>
    </select>

    <p>DOMAČA EKIPA:</p>
    <input type="text" name="doma" placeholder="<?php echo $errors["priimek"];?>"  required>

    <p>GOSTUJOČA EKIPA:</p>
    <input type="text" name="gost" placeholder="<?php echo $errors["priimek"];?>"  required>

    <p>IZBIRA:</p>
    DOMAČA EKIPA<input type="radio" name="izbira" value="1" checked style="width:15%"> 
    GOSTUJOČA EKIPA<input type="radio" name="izbira" value="2" style="width:15%"> <br>

    </div>

    <div class="l">

    <p>KVOTA:</p>
    <input type="number" name="kvota" step="0.01" min="1" placeholder="<?php echo $errors["user"];?>" required>

    <p>BESEDILO:</p>
    <textarea rows="8" cols="50" name="besedilo" placeholder="Napiši kratko razlago" style="width:99%"></textarea><br>
    <br>
    <br>
    <input type="submit" value="OBJAVI">

        </div>
</form>

</div>

</div>

</body>
</html>


