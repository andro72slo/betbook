<!DOCTYPE html>
<html>
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="style.css?v=<?php echo time(); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta charset="UTF-8" />
<script src="script.js"></script>

</head>
<body>

<div class="topnav" id="myTopnav">

  <a class="active">Betbook</a>
  <a href="nasveti.php">Nasveti</a>
  <?php
  session_start();
  if(isset($_SESSION["id"])){
      echo '<a href="dodaj.php">Objavi</a>';
      echo '<a href="mojestave.php">Moje objave</a>';
      echo '<a href="odjava.php" style="float:right">Odjava</a>';
  }
  else{
      echo '<a href="registracija.php" class="desno" style="float:right" > Registracija</a>';
      echo '<a href="prijava.php" style="float:right" >Prijava</a>';
  }
   
  ?>
  <a href="javascript:void(0);" class="icon" onclick="menu()">
    <i class="fa fa-bars"></i>
  </a>

</div>



<?php

if(isset($_SESSION["id"])){

    echo '<div class="profil">';
    echo '<img src="profile.jpg" style="width:100px" alt="slika">';
    echo '<span style="font-size:25px; font-weight:bold;">'.$_SESSION["user"] .'</span>';
    echo'<br>';
    echo '<h4>'.$_SESSION["ime"].' '.$_SESSION["priimek"].'</h4>';
    echo '<h4>'.$_SESSION["email"] .'</h4>';
    echo'<br>';

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "st_naloga";

    $conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
      
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


          $stmt = $conn->prepare("SELECT COUNT(*) AS 'st' FROM objava WHERE userid = :user AND status = 1");
          $stmt->bindParam(':user', $_SESSION["id"]);

          $stmt->execute();
          $result = $stmt->fetch();

          $win = $result["st"];
  

    echo '<h4>Pravilni nasveti: '. $result["st"] .'</h4>';

    $stmt = $conn->prepare("SELECT COUNT(*) AS 'st' FROM objava WHERE userid = :user AND status = 2");
          $stmt->bindParam(':user', $_SESSION["id"]);

          $stmt->execute();
          $result = $stmt->fetch();

          $lost = $result["st"];

    echo '<h4>Napačni nasveti:'. $result["st"] .'</h4>';

    $stmt = $conn->prepare("SELECT COUNT(*) AS 'st' FROM objava WHERE userid = :user AND status = 0");
          $stmt->bindParam(':user', $_SESSION["id"]);

          $stmt->execute();
          $result = $stmt->fetch();

    echo '<h4>Čakajoči nasveti:'. $result["st"] .'</h4>';
    echo'<br>';

    $p = ($win / ($win + $lost)) *100;

    echo '<h4>USPEŠNOST : '.$p.'%</h4>';

    echo '</div>';
}

?>



<div class="iskanje">
<div class="form">
    <form action="mojestave_filter.php" method="POST">
        <span>UREDI PO:</span>
        <select name="isci">
            <option value="kvota">KVOTA</option>
            <option value="ocena">OCENA</option>
            <option value="status">STATUS</option>
            <option value="sportid">ŠPORT</option>
        </select><br>
        <input type="radio" name="red" value="ASC" style="width:10%" checked><span>NARAŠČUJOČE:</span><br>
        <input type="radio" name="red" value="DESC" style="width:10%"><span>PADAJOČE:</span><br>
        <input type="submit" value="IŠČI">
    </form>
</div>
</div>





<div class="nasveti">

<?php

    $servername = "localhost";
    $username = "root";
    $password = "";

    $conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
    
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $stmt = $conn->query("SELECT o.*, u.user, s.naziv FROM objava o INNER JOIN uporabnik u ON(o.userid = u.id) INNER JOIN sport s ON(s.id = o.sportid) WHERE u.id = ".$_SESSION["id"]." ORDER BY ".$_POST["isci"]." ".$_POST["red"]." LIMIT 10");
    while ($row = $stmt->fetch()) {?>


<div class="objava" style= "background-color: white; "> 
    <img src="profile.jpg" style="width:40px" alt="slika">
    <span><?php echo $row["user"]; ?></span>
    <?php if($row["status"] == 0){echo "<span class='status'>WAITING</span>";}
          if($row["status"]==1){echo "<span class='status_green'>WON</span>";};
          if($row["status"]==2){echo "<span class='status_red'>LOST</span>";}; ?>
    <div class="u">
    <div class="rr">
    <h4>ŠPORT: <?php echo $row["naziv"]; ?></h4>
    <h4>TEKMA: <?php echo $row["doma"]; ?> VS <?php echo $row["gost"]; ?></h4>
    </div>
    <div class="ll">
    <h4>KVOTA: <?php echo $row["kvota"]; ?></h4>
    <h4>IZBIRA: <?php if($row["izbira"] == 1){echo $row["doma"];}else{echo $row["gost"];} ?></h4>
    </div>
    <h4>OBJASNILO:</h4>
    <p><?php echo $row["besedilo"]; ?></p>
    
    
    <?php
        if($row["status"] == 0){
            echo "<button class='st' onclick=\"status('".$row["id"]."','1')\">ZMAGA</button>";
            echo "<button class='st' onclick=\"status('".$row["id"]."','2')\">PORAZ</button>";
        }
    ?>
    </div>

</div>
<br>    
    
<?php  }
?>

</div>






</body>
</html>
