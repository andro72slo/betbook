<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "st_naloga";
session_start();

if(isset($_SESSION["id"])){

            $conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
        
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


            $stmt = $conn->prepare("SELECT * FROM ocena WHERE userid = :user AND objavaid = :id LIMIT 1");
            $stmt->bindParam(':user', $_SESSION["id"]);
            $stmt->bindParam(':id', $_POST["id"]);

            $stmt->execute();
            $result = $stmt->fetch();


            if($result["id"] == ""){
                $stmt = $conn->prepare("UPDATE objava SET ocena = ocena + :l WHERE id = :id");
                $stmt->bindParam(':id', $_POST["id"]);
                $stmt->bindParam(':l', $_POST["l"]);

                $stmt->execute();

                $stmt = $conn->prepare("INSERT INTO ocena (objavaid, userid) VALUES (:id, :user)");
                $stmt->bindParam(':id', $_POST["id"]);
                $stmt->bindParam(':user', $_SESSION["id"]);

                $stmt->execute();
            }


}



?>