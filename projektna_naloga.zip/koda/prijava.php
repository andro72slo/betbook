<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css?v=<?php echo time(); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta charset="UTF-8" />
<script src="script.js"></script>

</head>
<body>

<div class="topnav" id="myTopnav">

  <a class="active">Betbook</a>
  <a href="nasveti.php">Nasveti</a>
  <?php
  session_start();
  if(isset($_SESSION["id"])){
      echo '<a href="dodaj.php">Objavi</a>';
      echo '<a href="mojestave.php">Moje objave</a>';
      echo '<a href="odjava.php" style="float:right">Odjava</a>';
  }
  else{
      echo '<a href="registracija.php" class="desno" style="float:right" > Registracija</a>';
      echo '<a href="prijava.php" style="float:right" >Prijava</a>';
  }
   
  ?>
  <a href="javascript:void(0);" class="icon" onclick="menu()">
    <i class="fa fa-bars"></i>
  </a>

</div>






<div class="login-page">
  <div class="form">
    <form class="login-form" method="POST">
      <input type="text" name="user" placeholder="UPORABNIŠKO IME"/>
      <input type="password" name="geslo" placeholder="GESLO"/>
      <input type="submit" value="PRIJAVA">
    </form>
  </div>
</div>

<?php

$servername = "localhost";
$username = "root";
$password = "";

if(!empty($_POST)){

    try {
        $conn = new PDO("mysql:host=$servername;dbname=st_naloga", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
    
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $conn->prepare("SELECT * FROM uporabnik WHERE user = :user LIMIT 1");
        $stmt->bindParam(':user', $_POST["user"]);

        $stmt->execute();
    
        
        $result = $stmt->fetch();


        if($result["geslo"] == $_POST["geslo"] && $_POST["geslo"] != ""){
            session_start();
            $_SESSION["id"] = $result["id"];
            $_SESSION["ime"] = $result["ime"];
            $_SESSION["priimek"] = $result["priimek"];
            $_SESSION["email"] = $result["email"];
            $_SESSION["user"] = $result["user"];

            echo $_SESSION["email"];
            header('Location: nasveti.php'); 

        }





        }
    catch(PDOException $e)
        {
        echo "Connection failed: " . $e->getMessage();
        }
   

}

?>



</body>
</html>




