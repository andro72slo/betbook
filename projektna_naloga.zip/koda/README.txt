UPORABNIKI:
uporabniško ime   |     geslo
----------------------------------
andro             |     andro
user              |     geslo
miha55            |     geslo

Da bo spletna stran delovala more phpmyadmin vsebovati bazo betbook.db