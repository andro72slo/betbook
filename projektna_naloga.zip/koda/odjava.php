
<?php

Session_start();
Session_destroy();


header('Location: nasveti.php');

?>