function like($id){
    var a = document.getElementById($id); 
    a.innerHTML = Number(a.innerHTML) + 1;

    $.ajax({
      url: "like.php",
      data: {id : $id, l : 1},
      type: "POST",
      success: function(data){
      },
  });
    
}

function dislike($id){
    var a = document.getElementById($id); 
    a.innerHTML = Number(a.innerHTML) - 1;

    $.ajax({
      url: "like.php",
      data: {id : $id, l : -1},
      type: "POST",
      success: function(data){
      },
  });
}

function menu() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }


  function won($id){
    $.ajax({
        url: "won.php",
        data: {id : $id},
        type: "POST",
        success: function(data){
            location.reload();
        },
    });
}


function status($id, $s){
  $.ajax({
      url: "status.php",
      data: {id : $id, s : $s},
      type: "POST",
      success: function(data){
          location.reload();
      },
  });
}